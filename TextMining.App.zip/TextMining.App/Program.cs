﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DocumentFormat.OpenXml.Packaging;
using NMeCab;

namespace TextMining.App
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = "C:\\障害報告書\\【障害報告書】製品サイトの商品検索機能の障害報告書.docx";

            string sentence = GetTextFromWord(path);

            // NMeCab はクラス名が変更されている
            MeCabTagger t = MeCabTagger.Create();

			// 形態素を一つずつたどっていく
			Console.WriteLine("形態素をひとつずつたどっていく");
			MeCabNode node = t.ParseToNode(sentence);
			while (node != null)
			{
				Console.WriteLine(node.Surface + "\t" + node.Feature);
				node = node.Next;
			}
			Console.WriteLine();

			// 一気に結果をもらう
			Console.WriteLine("一気に結果をもらう");
			string result = t.Parse(sentence);
			Console.WriteLine(result);
		}

        static public string GetTextFromWord(string filePath)
        {
            try
            {
                //shout out to KyleM - Stack Overflow
                const string wordmlNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                StringBuilder textBuilder = new StringBuilder();
                using (WordprocessingDocument wdDoc = WordprocessingDocument.Open(filePath, false))
                {
                    // Manage namespaces to perform XPath queries.  
                    NameTable nt = new NameTable();
                    XmlNamespaceManager nsManager = new XmlNamespaceManager(nt);
                    nsManager.AddNamespace("w", wordmlNamespace);

                    // Get the document part from the package.  
                    // Load the XML in the document part into an XmlDocument instance.  
                    XmlDocument xdoc = new XmlDocument(nt);
                    xdoc.Load(wdDoc.MainDocumentPart.GetStream());

                    XmlNodeList paragraphNodes = xdoc.SelectNodes("//w:p", nsManager);
                    foreach (XmlNode paragraphNode in paragraphNodes)
                    {
                        XmlNodeList textNodes = paragraphNode.SelectNodes(".//w:t", nsManager);
                        foreach (System.Xml.XmlNode textNode in textNodes)
                        {
                            textBuilder.Append(textNode.InnerText);
                        }
                        textBuilder.Append(Environment.NewLine);
                    }

                    wdDoc.MainDocumentPart.GetStream().Flush();
                    wdDoc.MainDocumentPart.GetStream().Close();
                }

                return textBuilder.ToString();
            }
            catch (Exception e)
            {
                return "";
            }
        }
    }
}
